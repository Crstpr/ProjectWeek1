import React, { useEffect, useRef, useState } from 'react'
import todo from '../assets/calendar.png'
import Items from './Items'


const ToDo = () => {

const [TaskList, setTaskList] = useState(localStorage.getItem("tasks")? JSON.parse(localStorage.getItem("tasks")) : []);

const inputRef = useRef();

const add = () => {
    const inputText = inputRef.current.value.trim();

    if(inputText === ""){
      return null;
    }

    const newTask = {
      id : Date.now(),
      text : inputText,
      isComplete : false,
    }

    setTaskList((prev)=> [...prev, newTask]);
    inputRef.current.value = "";
}

const deleteTask = (id)=>{
    setTaskList((prevTask)=>{return prevTask.filter((task)=>task.id !== id)})

}

const toggle = (id)=>{
    setTaskList((prevTask)=>{
      return prevTask.map((task)=>{if(task.id === id){
        return{...task, isComplete: !task.isComplete}
      }
      return task;
    })
  })
}

useEffect(()=>{localStorage.setItem("tasks", JSON.stringify(TaskList))},[TaskList]);

  return (
    <div className='bg-white place-self-center w-11/12 max-w-md flex flex-col p-7 min-h-[550px] rounded-xl'>
    
    <div className='flex items-center mt-7 gap-2'>
        <img className='w-7' src={todo} alt="" />
        <h1 className='text-2xl font-bold'>To-Do List</h1>
    </div>

    <div className='flex items-center my-7 bg-gray-100 rounded-full'>
        <input ref={inputRef} className= 'bg-transparent border-none outline-none flex-1 h-14 pl-6 pr-2 placeholder:text-slate-600' type="text" placeholder='Add new task' />
        <button onClick={add} className='border-none rounded-full bg-neutral-400 w-24 h-14 text-white text-lg font-mono cursor-pointer'>Add +</button>
    </div>

    <div>
    {TaskList.map((item, index)=>{
      return <Items key={index} text={item.text} id={item.id} isComplete={item.isComplete} deleteTask={deleteTask} toggle={toggle}/>
    })}

    </div>

    </div>
  )
}

export default ToDo
